﻿default jst1=Character("魏大勋")
default jst2=Character("你")
default jst3=Character(" ")
image kj1="images/kj1.png"
image kj2="images/kj2.png"
image kj3="images/kj3.png"
image kj4="images/kj4.png"
image kj5="images/kj5.png"

default Affinity = 0
default Concession = 0


label start:
    queue music"rules.mp3"
    scene kjsm
    $ renpy.pause()
    scene black with fade
    scene kjm
    show text "欢迎各位玩家来到《Paris in the rain》"
    $ renpy.pause()
    hide text with dissolve
    show text "在这里，每个选项都充满了无限可能"
    $ renpy.pause()
    hide text with dissolve
    show text "你不必因为想要达成某种结局而违心地选择某些选项"
    $ renpy.pause()
    hide text with dissolve
    show text "just follow your heart"
    $ renpy.pause()
    hide text with dissolve
    show text "如果你已经做好了交付真心的准备，那么就开始吧"
    $ renpy.pause()
    hide text with dissolve
    show text "身份介绍"
    $ renpy.pause()
    hide text with dissolve
    show text "你是出生于艺术世家的燕小姐，也是圈内最年轻的运营总监"
    $ renpy.pause()
    hide text with dissolve
    show text "因为工作和身份的缘故，你免不了参加各式社交活动"
    $ renpy.pause()
    hide text with dissolve
    show text "这些年向你示好的杰出男性不少"
    $ renpy.pause()
    hide text with dissolve
    show text "但你心里一直有一个不切实际的想法"
    $ renpy.pause()
    hide text with dissolve
    show text "你从没和任何人提起过，在你心里有一个特别的存在，"
    $ renpy.pause()
    hide text with dissolve
    show text "而这个人......和你隔着一层薄薄的屏幕"
    $ renpy.pause()
    hide text with dissolve
    scene black with fade
    scene kj2
    show text "你终于有机会线下见到他，要感谢一场晚宴"
    $ renpy.pause()
    hide text with dissolve
    play sound wanyan_1
    show text "那时你28岁，刚结束在法国为期三年的工作"
    $ renpy.pause()
    hide text with dissolve
    show text "回国入职成为一家珠宝品牌中国区的副总监"
    $ renpy.pause()
    hide text with dissolve
    show text "虽然职位如此，但说到底也是新人，你还带着初入职场的忐忑和心气"
    $ renpy.pause()
    hide text with dissolve
    show text "那时他32岁，还不像现在这样无时无刻被人群簇拥着，但也算小有名气"
    $ renpy.pause()
    hide text with dissolve
    show text "晚宴进行至大半，周围人的交谈夹杂着音乐让你觉得俗气至极"
    $ renpy.pause()
    hide text with dissolve
    show text "你无聊地环顾四周，恰好对上一双瞳孔"
    $ renpy.pause()
    hide text with dissolve
    scene kj1
    $ renpy.pause()
    hide text with dissolve
    jst3 "是他"
    stop sound fadeout 1.0
    jst3 "四目相对未免有些尴尬，你只好礼貌地笑了笑，对面的人也微微点头"
    jst3 "朝思暮想的第一次见面，你竟无法准确描述出他给你的感觉，只记得那双瞳孔里映着舞台幽蓝的光"
    jst3 "你甚至怀疑这是一场梦"
    $ renpy.pause()
    hide text with dissolve
    scene kj1
    jst3"晚宴结束的时候，你在休息室又遇到了他。"
    jst2"Hi？魏先生，这么巧，又见面了。"
    jst1"您好。"
    jst3"他似乎对于你认识他而有些惊讶"
    jst1"【俯身向你伸出手】"
    jst2"我是风瑟中国区的运营总监，这是我的名片。魏先生对我们品牌有了解吗？"
    jst3"【斟酌着，你向他抛出了橄榄枝】"
    jst1"【静静地听着，时不时点点头】"
    jst3"聊毕"
    jst1"燕总监，很高兴认识你，如果后续我们有缘分达成合作的话，请和我的工作室联系具体细节好吗？这是我工作室的邮箱。"
    jst3"【不是吧？这么严谨？连个微信都不给加？？】"
    menu:
        "向他提出加微信的请求":
            $ Affinity += 3  
            jump Character1  
        "只是记下工作室邮箱":
            $ Concession += 2
            jump Character2
   
label Character1:
    scene kj1
    jst2"好啊，不过...魏先生方便加一个联系方式吗？我本人也很喜欢看你的戏。"
    jst1"嗯...那我扫您。"
    jst3"他思索了一下，还是同意了"
    jst3"他拿出手机，你注意到手机壳上的布朗熊"
    jump Character3
label Character2:
    scene kj1
    jst2"好啊，那就...期待我们后续的合作。"
    jst3"【你不想让魏大勋感到冒昧，最终还是没有提出加微信的请求】"
    jump Character5

label Character3:
    scene kj5  
    jst3"那天回去之后，你让手下的负责人拟了合作计划。"
    jst3"起初你还有些忐忑，毕竟这次合作...是你带着私心。"
    jst3"没想到公司那边很快就通过了，并且决定让你全权负责本次合作进度。"
    menu:
        "向工作室提出去一家私人会客厅见面详谈":
            $ Affinity += 2  
            jump Character4  
        "向工作室提出去公司会议室见面详谈":
            $ Concession += 3
            jump Character4
label Character5:
    scene kj5  
    jst3"那天回去之后，你让手下的负责人拟了合作计划"
    jst3"起初你还有些忐忑，毕竟这次合作...是你带着私心"
    jst3"没想到公司那边很快就通过了，并且决定让你全权负责本次合作进度"
    menu:
        "向工作室提出去一家私人会客厅见面详谈":
            $ Affinity += 2  
            jump Character6  
        "向工作室提出去公司会议室见面详谈":
            $ Concession += 3
            jump Character6
label Character4:
    scene kj4
    jst3"你终于看见了他私下里的样子"
    jst3"来之前你特意强调不需要太过正式的准备，这次会面只是来确认产品风格"
    jst3"十月的北京天气已经转凉，他穿着一件polo领的黑色夹克，衬得皮肤愈发瓷白"
    jst3"没了发胶，魏大勋前额的刘海垂下来，发尾扫过睫毛，像一只凌乱的蝴蝶"
    jst1"总监？"
    jst3"你回过神来，忙招呼着一行人坐下"
    jst3"说是一行人，除了他本人就只有一位执行经纪"
    jst2"这是最新一季的珠宝产品画册，你先看看风格。（把画册往他那边推了推）"
    scene kj6
    jst1"（接过去翻了两页，忽然停住，抬头）哎，这个系列的灵感...是雨吧？"
    jst2"（有点意外）你看出来了？"
    jst1"（指着耳饰的线条）我看这个弧度，看起来很像雨滴，还有这个留白...我瞎猜的啊，你是想做出雨雾的感觉？"
    jst2"（看着他）...你说得没错，准确来说它是巴黎的雨，我去年在国外也参与了这次设计。"
    jst2"不过，你是第一个这么快就看出来的。"
    jst1"（挑了挑眉，似乎有些惊讶）嗯。"
    jst3"他把画册返回到第一页，手指在一枚戒指的样品图边缘停了一下就再没说话"
    jst2"魏先生有什么顾虑吗？"
    jst1"我能问问贵公司...选择我的原因是？或者说，需要我以一个什么样的形象来配合风格宣传？"
    jst1"不好意思，可能有点直接，我对珠宝拍摄的经验不太多。"
    jst3"你看着他的眼睛，想起那天他眼里闪着的幽蓝的光"
    jst2"（想了两秒）晚宴那天，我觉得你好像和电视里...不一样。"
    jst2"总之，展示你真实的那一面就好，我相信我们的合作会很顺利。"
    play sound gm_1
    jst3"聊毕，魏大勋和经纪人离开会议室"
    scene kj7
    jst3"门关上之后，你靠在椅背上看着画册上那枚戒指"
    jst3"这枚戒指是你设计的"
    jst3"良久，你忍不住打开手机翻看起他的朋友圈"
    scene kj9
    jst3"最新一条来自五分钟前，是他拍的雨天。你看向窗外，才发现外面下雨了"
    menu:
        "点赞互动一番":
            $ Concession += 2 
            jump Character8  
        "犹豫了一下还是关上手机":
            $ Affinity += 3
            jump Character7

label Character6:
    scene kj4
    jst3"你终于看见了他私下里的样子"
    jst3"来之前你特意强调不需要太过正式的准备，这次会面只是来确认产品风格"
    jst3"十月的北京天气已经转凉，他穿着一件polo领的黑色夹克，衬得皮肤愈发瓷白"
    jst3"没了发胶，魏大勋前额的刘海垂下来，发尾扫过睫毛，像一只凌乱的蝴蝶"
    jst1"总监？"
    jst3"你回过神来，忙招呼着一行人坐下"
    jst3"说是一行人，除了他本人就只有一位执行经纪"
    jst2"这是最新一季的珠宝产品画册，你先看看风格。（把画册往他那边推了推）"
    scene kj6
    jst1"（接过去翻了两页，忽然停住，抬头）哎，这个系列的灵感...是雨吧？"
    jst2"（有点意外）你看出来了？"
    jst1"（指着耳饰的线条）我看这个弧度，看起来很像雨滴，还有这个留白...我瞎猜的啊，你是想做出雨雾的感觉？"
    jst2"（看着他）...你说得没错，准确来说它是巴黎的雨，我去年在国外也参与了这次设计。"
    jst2"不过，你是第一个这么快就看出来的。"
    jst1"（挑了挑眉，似乎有些惊讶）嗯。"
    jst3"他把画册返回到第一页，手指在一枚戒指的样品图边缘停了一下就再没说话"
    jst2"魏先生有什么顾虑吗？"
    jst1"我能问问贵公司...选择我的原因是？或者说，需要我以一个什么样的形象来配合风格宣传？"
    jst1"不好意思，可能有点直接，我对珠宝拍摄的经验不太多。"
    jst3"你看着他的眼睛，想起那天他眼里闪着的幽蓝的光"
    jst2"（想了两秒）晚宴那天，我觉得你好像和电视里...不一样。"
    jst2"总之，展示你真实的那一面就好，我相信我们的合作会很顺利。"
    jst2"加个微信？有些风格细节我想到再和你沟通。"
    play sound gm_1
    jst1"好。"
    jst3"聊毕，魏大勋和经纪人离开会议室"
    scene kj8
    jst3"门关上之后，你靠在椅背上看着画册上那枚戒指"
    jst3"这枚戒指是你设计的"
    jst3"良久，你忍不住打开手机翻看起他的朋友圈"
    scene kj9
    jst3"最新一条来自五分钟前，是他拍的雨天，你看向窗外才发现外面下雨了"
    menu:
        "点赞互动一番":
            $ Concession += 2  
            jump Character8  
        "犹豫了一下还是关掉手机":
            $ Affinity += 3 
            jump Character7

label Character7:
    scene kj9
    jst3"手指在点赞键上悬了好一会儿，你最终还是按灭了手机"
    jst3"但你觉得少了点什么"
    jst3"手机屏幕暗了又亮，长按，保存。仿佛不受控地，你存下了这张照片"
    $ renpy.pause()
    hide text with dissolve
    jump Character771

label Character8:
    scene kj9
    jst3"你出神地看了一会，随手点了一个赞"
    $ renpy.pause()
    hide text with dissolve
    jump Character9

label Character9:
    scene black with fade
    scene kj10
    jst3"拍摄的日子很快就到来，你把拍摄地点定在了户外"
    jst3"其实这些事你本不需要过问，但他身上有种莫名的吸引力让你忍不住靠近"
    jst3"上次结束面谈之后，你在微信里又和魏大勋沟通了一些灵感细节"
    jst3"即使是线上沟通，他也总能快速get到你的构思"
    jst3"甚至...你觉得你们之间培养出了一点似有若无的默契"
    jst3"就连称呼也...更亲近了些"
    jst3"我们...现在能算是朋友吗？"
    $ renpy.pause()
    hide text with dissolve
    scene kj11
    jst3"拍摄的第一套是耳饰"
    jst3"耳坠飘忽不定地摇晃，晃得你的心有些乱"
    jst3"和平时的状态截然不同，魏大勋拍摄的时候很沉浸"
    jst3"虽然拍摄的是耳饰，但你指明了要一套显腰身的衣服，完美的三七分身材让你觉得他不做模特简直可惜"
    play sound yv_1
    jst3"拍摄进行至大半，刚刚还晴好的天气突然落了雨滴"
    jst3"机器不能淋雨，你只得叫停了拍摄"
    jst3"幸好你提前找附近的咖啡店包了场，于是你顺理成章地邀请大家喝咖啡"
    menu:
        "邀请魏大勋同去":
            $ Affinity += 3
            jump Character10
        "向他表示歉意":
            $ Concession += 3
            jump Character11
label Character10:
    scene kj12
    jst2"机器没办法淋雨拍摄，不然我们先歇歇？"
    jst1"（点点头）也好，那我们随时联系。（随即准备回到车上休息）"
    jst3"他眼看着要走，但你不想放弃和他相处的机会"
    jst2"勋哥，我在附近的咖啡厅包了场，或许...我们过去复盘一下拍摄细节？"
    jst2"上好的瑰夏咖啡豆...要不要尝尝？"
    jst1"（愣了一下）（笑着）燕总监对客户的喜好都了解得这么详细吗？"
    jst2"【完蛋了，司马昭之心昭然若揭。。】"
    jst2"职业病哈哈哈..."
    jst3"你有些不自然地笑着打哈哈"
    jst3"那个，我能不能搭个车？咖啡店距离这里还有一段距离"
    jst1"妹妹你不嫌我车小就行。"
    jst3"【呼...你有些不好意思】"
    jump Character12
label Character11:
    scene kj12
    jst2"（有些懊恼）抱歉啊哥，是我没看好天气。"
    jst1"（笑着安慰你）问题不大，刚好大家也歇歇。"
    jst2"我在附近的店包了场，请大家过去喝杯咖啡。"
    jst1"既然我们总监这么破费那我可得去尝尝了。（笑着打趣缓解你的不安）"
    jump Character12
label Character12:
    stop sound fadeout 2.0
    scene kj14
    jst3"咖啡厅里一时间聚集了你们的工作人员，显得有些吵"
    jst3"你带着魏大勋一行人去了楼上"
    jst3"店铺是日咖夜酒的设计，二楼白天不开放也就清净些"
    scene kj13
    jst3"你看见魏大勋身边几个工作人员还有些拘谨，于是说为了表示歉意，让大家随便点自己想喝的"
    jst1"那你这么说我们可得好好宰你一顿了妹妹。"
    jst3"他总是能轻易就化解你的尴尬和忐忑。明明他和你一样是年轻人，却总是带着游刃有余的从容"
    jst1"一杯冰美式，谢谢。"
    jst3"menu上的咖啡名字众多，有些连你都没听过，但他只点了一杯冰美式"
    jst2"【不愧是冰美式爱好者。。】"

    menu:
        "聊起你的戒指设计":
            $ Affinity += 2
            jump Character13
        "聊起你在国外的经历":
            $ Concession += 3
            jump Character14

label Character13:
    scene kj16
    jst2"我们还剩下最后一组戒指需要拍摄。"
    jst1"嗯，那枚戒指很特别。"
    jst3"咖啡淡淡的苦味漫在空气里"
    jst2"...嗯。（你垂着眼，视线落在桌面）你怎么知道是我设计的？"
    jst1"（轻笑一声）你的画册上可写了啊妹妹，我那天在会议室就看到了。"
    jst2"（有些尴尬）我还以为你不知道。"
    jst3"一时间你喉咙发紧，其实这套饰品从一开始就是下意识以他为原型构想的"
    jst3"那天巴黎依旧是雨天，你在社交平台上刷到他的哭戏，像一场雨"
    jst2"算不上什么特别的寓意。只是一点偶然的灵感而已...大概只有我自己能懂。"
    jst1"嗯（低低应了一声）燕总监很有想法。"
    jst3"【听见他的回答，你忍不住妄想，妄想现在不是在拍摄广告，而是别的什么】"
    jst2"（扯出一点很浅的笑意）希望拍的时候你会喜欢。"
    jump Character15
label Character14:
    scene kj16
    jst2"北京的雨和巴黎的不一样。"
    jst1"你之前在巴黎？"
    jst3"听见他问起你在国外的经历，那些冷调的记忆翻涌上来"
    jst1"看你像是曾经在国外待很久？"
    jst2"（淡淡笑了笑）从大学开始就一个人在国外待着了，家里人让我学设计，但我现在还是跑回国来做运营。（苦笑）"
    jst1"一个人在外，应该会很辛苦。"
    jst3"你没想到他会这样说"
    jst1"年少有为很不容易。"
    jst3"你突然很烦躁，突然意识到他是不是对所有人都这样共情"
    jst2 "我还以为你会觉得我很叛逆。"
    jump Character15
label Character15:
    scene kj14
    menu:
        "邀请他下次一起喝咖啡":
            $ Affinity += 3
            jump Character16
        "说起巴黎时装周":
            $ Concession += 2
            jump Character17

label Character16:
    scene kj14
    jst3"一杯咖啡刚好喝完，窗外的雨适时地停了"
    jst2"下次我们还有机会一起喝咖啡吗？"
    jst1"（笑得眯了眼）只要你不怕失眠。"
    jst3"你笑起来，终于明白为什么他的拍摄现场总是那么欢乐"
    jump Character18
label Character17:
    scene kj14
    jst2"你去过巴黎吗？"
    jst1"你要说巴黎，那我可去过深圳的世界之窗。"
    jst3"你忍不住笑起来，突然很想带他去看你生活过的地方"
    jst2"你想去玩一圈吗？"
    jst2"别多想啊，我是觉得时装周很适合你，刚好我们下一季的产品想要过去参展，大概是明年一月份。"
    jst2"我是真心地邀请你去。"
    jst1"燕总给我这么好的机会那我当然要去了。"
    jst3"一杯咖啡刚好喝完，窗外的雨适时地停了"
    jst2"那就这么说定了，我回去拟好新的合同发给你。"
    jump Character18

label Character18:
    scene black with fade
    scene kj5
    jst3"拍摄结束后的两周里，你一直在寻找一个契机见面"
    jst3"对话框里的文字敲了又删，你始终不知道该如何开口"
    jst3"你听说他私下里总是淡淡的，很少答应别人的聚会邀请"
    jst3"但他对你的态度又总是让你产生一种错觉"
    jst3"最后，你让助理做了一版简单的时装周参展策划给他发了过去"
    jst2"巴黎时装周，希望你会喜欢。"
    jump Character19

label Character19:
    scene black with fade
    scene kj15
    show text "北京迎来了第一场寒潮"
    $ renpy.pause()
    hide text with dissolve
    show text "那天你加班到深夜，走出写字楼的时候外面下了雨夹雪"
    $ renpy.pause()
    hide text with dissolve
    show text"你随手发了一条朋友圈抱怨这个鬼天气还要加班后切到了打车软件"
    $ renpy.pause()
    hide text with dissolve
    show text "已经是午夜十二点，你不想麻烦司机来接一趟于是干脆打车回家"
    $ renpy.pause()
    hide text with dissolve
    play sound md_1
    show text "就在你等着出租车接单的时候，一辆黑色迈巴赫在路边停下来"
    $ renpy.pause()
    hide text with dissolve
    show text "你还在疑惑这应该不是自己叫的车"
    $ renpy.pause()
    hide text with dissolve
    show text "车窗稳稳降下，露出精致的一张脸"
    $ renpy.pause()
    scene black with fade
    scene kj17
    jst1 "上车。"
    jst1 "这里不让停太久。"
    jst3 "你愣了一下，拉开车门坐了进去"
    scene kj18
    jst3 "车里很暗，只有路灯的光一闪一闪地掠过他的侧脸"
    jst2 "你怎么会在这儿？"
    jst1 "刚好路过。"
    jst1 "（看着前方）"
    jst1 "看到有个傻子在淋雨。"
    jst3 "车里放着很轻的纯音乐"
    jst3 "暖气开得很足，空气里混合着一种极淡的乌木味道"
    jst3 "那是他身上特有的味道"
    jst1 "倒是你，大半夜不睡觉还在公司加班？"
    jst2 "嗯，年底了。"
    jst3 "他沉默了一会儿"
    jst1 "以你的职位，应该不用这样亲力亲为吧。"
    jst2 "你说得没错，但...我毕竟是新人嘛，不想让别人觉得我是靠家里才坐到这个位置。"
    jst2 "但我最近觉得...事实好像真的是这样。（苦笑）"
    jst1 "怎么？燕总轻易就会因为别人的几句话内耗？"
    jst2 "才没有。（撇过脸）"
    jst1 "（见你不愿多说，轻叹一口气）其实你没必要非去陷入一个自证怪圈，你的能力和家世都是你的底气。"
    jst3 "他说这话的时候很认真地看着你，带着关切的语气"
    jst2 "【我的能力和家世...都是我的底气吗？】"
    jst3 "你靠着车窗，视线落到他沾着雪花的皮鞋上，亮晶晶的"
    menu:
        "告诉他你的住址":
            $ Concession += 3
            jump Character20
        "一路无言":
            $ Affinity += 2
            jump Character21
    jst3 "车子开得很稳，你吹着暖风终于忍不住沉沉睡去。"
label Character21:
    scene black with fade
    scene kj20
    jst1"醒醒，到了。"
    jst3"乌木的香气欺压过来，你睁眼看见魏大勋已经打开了你这边的车门"
    jst2"（灯光晃得你睁不开眼）到哪了？"
    jst1"我的酒店。"
    jst1"我可不是趁人之危啊，你又没告诉我你家在哪。正好我剧组酒店离着近，你就在这凑合一晚吧，助理已经订好房间了，工作人员也都跟着呢。"
    scene black with fade
    scene kj21
    jst3"他在前面撑伞稳稳地走着"
    jst3"宽阔的背影让你有种莫名的心安"
    jst3"你反复告诉自己这不是梦"
    jump Character24

label Character24:
    scene black with fade
    scene kj22
    jst3"洗漱之后已经凌晨两点了，刚刚车上那一觉睡得很安稳，现在反倒睡不着了"
    jst3"你打开微博随意刷着"
    jst3"从前你总是通过这个软件获取他的一切近况，自从你们有了联系之后你就很少打开了"
    jst3"他今天看样子是刚下戏，你有点好奇是什么剧组要拍到这么晚"
    jst3"你突然发现不对，瞬时脑子里闪过一万种玛丽苏小说情节"
    jst3"当年果郡王去宁古塔也说顺路。。"
    jst3"你想起刚刚那条朋友圈，不敢再去想一些细节"
    jst2"也许人家真是顺路呢。"
    jst2"找时间请他吃饭好了。"
    jump Character25

label Character20:
    scene black with fade
    scene kj20
    jst1"醒醒，到了。"
    jst3"乌木的香气欺压过来，你睁眼看见魏大勋已经打开了你这边的车门"
    jst2"（灯光晃得你睁不开眼）到哪了？"
    jst1"（笑着）自己家不认识了？（递伞）"
    jst2"（不好意思）今天真的很谢谢你...我请你吃饭吧，还有巴黎行程的细节我也一并敲定了发给你。"
    jst1"行了妹妹，还聊工作呢，你这不早了赶紧回去休息吧。"
    jst3"你再次道了谢，接过伞向小区门口走去"
    jst3"车灯在你身后亮了很久"
    jump Character22

label Character22:
    scene black with fade
    scene kj22
    jst3"洗漱之后已经凌晨两点了，刚刚车上那一觉睡得很安稳，现在反倒睡不着了"
    jst3"你打开微博随意刷着"
    jst3"从前你总是通过这个软件获取他的一切近况，自从你们有了联系之后你就很少打开了"
    jst3"他今天看样子是刚下戏，你有点好奇是什么剧组要拍到这么晚"
    jst3"你突然发现不对，瞬时脑子里闪过一万种玛丽苏小说情节"
    jst3"当年果郡王去宁古塔也说顺路。。"
    jst3"你想起刚刚那条朋友圈，不敢再去想一些细节"
    jst2"也许人家真是顺路呢。"
    jst2"找时间请他吃饭好了。"
    jump Character23

label Character25:
    scene black with fade
    scene kj23
    jst3"一周后，你得知魏大勋的新戏杀青了"
    jst3"你挑了一家隐蔽性极好的私人餐厅，想着一来算是还他那晚的人情，二来正好庆祝他杀青"
    scene kj24
    jst3"他到的时候包厢里刚好放着一首很老的爵士乐"
    jst3"他换了件黑色的高领毛衣，头发散散地搭在额前"
    jst3"网上很火的那句话怎么说的来着？"
    jst3"哦对，人夫感"
    jst1 "来得这么早？"
    jst2 "（笑着）怕大明星档期太满来不及赶通告。"
    jst3"你知道他明天一早就要飞到另一个城市"
    jst1 "（低低地笑了一声）"
    jst1 "燕总这么盛情邀请那我必须有档期吧。"
    jst3"他拉开椅子的声音很轻"
    play sound sz_1
    jst3"席间你倒是没有急着开口提巴黎的策划案"
    jst3"房间里只有偶尔瓷勺碰到骨碟的轻响"
    jst3"你正低头喝汤，他突然用公筷夹了一块挑了刺的鱼肉，放进你面前的碟子里"
    jst1 "那天晚上..."
    jst1 "（顿了顿）"
    jst1 "没经过你同意就把你送到酒店实在是不好意思。"
    jst3"他突如其来的道歉让你心里一紧。"
    menu:
        "顺着他的话往下问":
            $ Affinity += 3
            jump Choice_Tease2
        "低头吃鱼掩饰慌乱":
            $ Concession += 2
            jump Choice_Escape2

label Choice_Tease2:
    scene kj25
    jst2 "嗯？（笑着）那怎么没叫醒我？"
    jst3"他放下筷子，手攥得紧了些"
    jst3"包厢里暖黄色的灯光衬得他的脸有些晦暗不明，像一场梦境"
    jst1 "看你在车里睡着了..."
    jst1 "（自嘲地笑了一下，避开了视线）"
    jst1 "（苦笑）如果叫醒你有点残忍。"
    jst3"冠冕堂皇"
    jump Character26

label Choice_Escape2:
    jst2"（低头）这鱼挺好吃的。"
    jst2"嗯...是我该谢谢你。"
    jst1 "（轻叹了一口气）"
    jst3 "你看到他垂下的眼睫似乎微微颤动了一下"
    jump Character26

label Character23:
    scene kj23
    jst3"一周后，你得知魏大勋的新戏杀青了"
    jst3"你挑了一家隐蔽性极好的私人餐厅，想着一来算是还他那晚的人情，二来正好庆祝他杀青"
    scene kj24
    jst3"他到的时候包厢里刚好放着一首很老的爵士乐"
    jst3"他换了件黑色的高领毛衣，头发散散地搭在额前"
    jst3"网上很火的那句话怎么说的来着？"
    jst3"哦对，人夫感"
    jst1 "来得这么早？"
    jst2 "（笑着）怕大明星档期太满来不及赶通告。"
    jst3"你知道他明天一早就要飞到另一个城市"
    jst1 "（低低地笑了一声）"
    jst1 "燕总这么盛情邀请那我必须有档期吧。"
    jst3"他拉开椅子的声音很轻"
    play sound sz_1
    jst3"席间，你没有急着开口提巴黎的策划案"
    jst3"房间里只有偶尔瓷勺碰到骨碟的轻响"
    jst2 "明天一早的飞机..."
    jst2 "怎么会这么赶？身体吃得消？"
    scene kj25
    jst1"（放下筷子，挑挑眉）嗯？"
    jst2"（抬头）"
    jst1"（笑得眯了眼）燕总这么关心乙方。"
    menu:
        "我还以为我们算朋友来着":
            $ Affinity += 3
        "我亲自找的乙方自然要多上心":
            $ Concession += 2
    jst3"你感觉到他似乎愣了一秒"
    jst1"那我以后可要多和燕总套套近乎了。"
    jump Character26

label Character26:
    scene kj27
    jst3"吃完饭出来你发现时间还早。"
    jst2"这家餐厅是我朋友开的，后面有一个私人公园，要不要逛逛？"
    jst1"也好。"
    scene kj26
    jst3"已经是初冬，魏大勋穿着一身羽绒服"
    jst3"他本来走得很快，发现你有点跟不上他就放缓了脚步"
    jst2"巴黎有很多公园，我晚上也会过去散步。"
    jst1"你很喜欢那里么？"
    jst2"也不算吧，只不过在我的人生阅历里，有挺多重要的时刻都是在那里度过的。"
    jst2"但是那里的饭很难吃（笑）"
    jst1"我也不爱吃外国菜，可能我是中国胃。"
    jst2"不过十三区有一家中餐很好吃，我们到时候可以去尝尝。"
    jst3"中餐邀请脱口而出的时候你们正在下台阶"
    scene kj28
    jst1"（回头看了你一眼）好。"
    jst3"你习惯了他总是打趣似的回答，没想到他只说了一个好字"
    jst3"你在思考这样太过热情的邀请是否有点越界，但管他呢，反正魏大勋同意了"
    jump Character27


label Character27:
    scene black with fade
    scene kj29
    "几周后。"
    "因为这次参展团队的人数不少，你干脆包了一架中型的商务客机直飞巴黎"
    "飞了几个小时大家都有些困，于是你吩咐调暗了机舱里的灯"
    "你和魏大勋坐在后排靠窗最舒适的位置"
    "困意如潮水般涌上来"
    "你原本想撑着再完善一些参展细节，但眼皮最终不受控制地合上了"
    "不知道过了多久"
    "飞机遇到了一阵轻微的气流颠簸"
    "你迷迷糊糊地醒来却发现自己并没靠在机舱壁上"
    "当你意识过来不对劲的时候已经晚了"
    "你的头正靠在一个温热的肩膀上"
    "熟悉的乌木味道将你完完全全地包裹着"
    "你猛地清醒过来，想要坐直身体"
    
    jst1 "（低声）"
    jst1 "你醒了？"
    
    "机舱里很安静"
    "他压低了声音，只有你们两个人能听见"
    jst2 "抱歉，实在对不起，我睡着了不知道怎么就...（环顾四周）"
    "你边道歉边拉开距离"
    "但他的肩膀依旧保持着刚才姿势没变"
    jst1 "（打断）没事。"
    jst1 "（偏过头，在昏暗的光线里看着你）"
    jst1 "为甲方服务。"
    "你才发现他的手只是抱着臂，还是一副绅士样子"
    "而你的腿上不知道什么时候盖上了他的毯子，座椅也好像被向后调了调" 
    menu:
        "把毯子还给他，有些不好意思":
            $ Affinity += 2
            jump Choice_Return_Coat
        "低声问他为什么不叫醒你":
            $ Concession += 3
            jump Choice_Ask_Why

label Choice_Return_Coat:
    jst2 "我不冷了，毯子还你吧。"
    jst3"说着你就要拿起腿上的毯子"    
    jst1 "得了，披着吧。"
    jst3"依旧是淡淡的语气"
    jump Character32
label Choice_Ask_Why:
    jst2 "你干嘛不叫醒我。"
    "他沉默了一会儿"
    "借着机舱里微弱的指示灯光，你看到他的喉结滚动了一下"
    
    jst1 "问题不大。"
    jump Character32

label Character32:
    scene kj30
    jst3"飞机上的人也陆陆续续醒过来"
    jst3"他拉开飞机窗户的挡板，外面竟是一片晚霞"
    jst3"你们默契地拿出了手机想要记录，他已经换了手机壳，但印花依旧是一只布朗熊"
    jst3"他记录的是晚霞，而你记录的其实是他"
    jst3"为了掩饰，你还是拍了几张风景照，随后把偷拍的照片存入了私密相册"
    jst1"怎么样？（拿过手机给你展示）"
    jst2"大明星还搞起摄影师副业了？"
    jst2"你如果不拍戏可以去当摄影师。"
    jst1"（打趣着）我这是给角色积累经验，万一我以后演了个摄影师。"
    jst1"不过啊，我最想当的还是老师，我喜欢管着别人（笑）。"
    jst3"你没忍住笑出声，也打开手机给他看你刚刚拍的晚霞"
    jump Character31


    








label Character771:
    scene black with fade
    scene kj10
    jst3"拍摄的日子很快就到来，你把拍摄地点定在了户外"
    jst3"其实这些事你本不需要过问，但他身上有种莫名的吸引力让你忍不住靠近"
    jst3"上次结束面谈之后，你在微信里又和魏大勋沟通了一些灵感细节"
    jst3"即使是线上沟通，他也总能快速get到你的构思"
    jst3"甚至...你觉得你们之间培养出了一点似有若无的默契"
    jst3"就连称呼也...更亲近了些"
    jst3"我们...现在能算是朋友吗？"
    $ renpy.pause()
    hide text with dissolve
    scene kj11
    jst3"拍摄的第一套是耳饰"
    jst3"耳坠飘忽不定地摇晃，晃得你的心有些乱"
    jst3"和平时的状态截然不同，魏大勋拍摄的时候很沉浸"
    jst3"虽然拍摄的是耳饰，但你指明了要一套显腰身的衣服，完美的三七分身材让你觉得他不做模特简直可惜"
    play sound yv_1
    jst3"拍摄进行至大半，刚刚还晴好的天气突然落了雨滴"
    jst3"机器不能淋雨，你只得叫停了拍摄"
    jst3"幸好你提前找附近的咖啡店包了场，于是你顺理成章地邀请大家喝咖啡"
    menu:
        "邀请魏大勋同去":
            $ Affinity += 3
            jump Character10771
        "向他表示歉意":
            $ Concession += 3
            jump Character11771
label Character10771:
    scene kj12
    jst2"机器没办法淋雨拍摄，不然我们先歇歇？"
    jst1"（点点头）也好，那我们随时联系。（随即准备回到车上休息）"
    jst3"他眼看着要走，但你不想放弃和他相处的机会"
    jst2"勋哥，我在附近的咖啡厅包了场，或许...我们过去复盘一下拍摄细节？"
    jst2"上好的瑰夏咖啡豆...要不要尝尝？"
    jst1"（愣了一下）（笑着）燕总监对客户的喜好都了解得这么详细吗？"
    jst2"【完蛋了，司马昭之心昭然若揭。。】"
    jst2"职业病哈哈哈..."
    jst3"你有些不自然地笑着打哈哈"
    jst3"那个，我能不能搭个车？咖啡店距离这里还有一段距离"
    jst1"妹妹你不嫌我车小就行。"
    jst3"【呼...你有些不好意思】"
    jump Character12771
label Character11771:
    scene kj12
    jst2"（有些懊恼）抱歉啊哥，是我没看好天气。"
    jst1"（笑着安慰你）问题不大，刚好大家也歇歇。"
    jst2"我在附近的店包了场，请大家过去喝杯咖啡。"
    jst1"既然我们总监这么破费那我可得去尝尝了。（笑着打趣缓解你的不安）"
    jump Character12771
label Character12771:
    stop sound fadeout 2.0
    scene kj14
    jst3"咖啡厅里一时间聚集了你们的工作人员，显得有些吵"
    jst3"你带着魏大勋一行人去了楼上"
    jst3"店铺是日咖夜酒的设计，二楼白天不开放也就清净些"
    scene kj13
    jst3"你看见魏大勋身边几个工作人员还有些拘谨，于是说为了表示歉意，让大家随便点自己想喝的"
    jst1"那你这么说我们可得好好宰你一顿了妹妹。"
    jst3"他总是能轻易就化解你的尴尬和忐忑。明明他和你一样是年轻人，却总是带着游刃有余的从容"
    jst1"一杯冰美式，谢谢。"
    jst3"menu上的咖啡名字众多，有些连你都没听过，但他只点了一杯冰美式"
    jst2"【不愧是冰美式爱好者。。】"

    menu:
        "聊起你的戒指设计":
            $ Affinity += 2
            jump Character13771
        "聊起你在国外的经历":
            $ Concession += 3
            jump Character14771

label Character13771:
    scene kj16
    jst2"我们还剩下最后一组戒指需要拍摄。"
    jst1"嗯，那枚戒指很特别。"
    jst3"咖啡淡淡的苦味漫在空气里"
    jst2"...嗯。（你垂着眼，视线落在桌面）你怎么知道是我设计的？"
    jst1"（轻笑一声）你的画册上可写了啊妹妹，我那天在会议室就看到了。"
    jst2"（有些尴尬）我还以为你不知道。"
    jst3"一时间你喉咙发紧，其实这套饰品从一开始就是下意识以他为原型构想的"
    jst3"那天巴黎依旧是雨天，你在社交平台上刷到他的哭戏，像一场雨"
    jst2"算不上什么特别的寓意。只是一点偶然的灵感而已...大概只有我自己能懂。"
    jst1"嗯（低低应了一声）燕总监很有想法。"
    jst3"【听见他的回答，你忍不住妄想，妄想现在不是在拍摄广告，而是别的什么】"
    jst2"（扯出一点很浅的笑意）希望拍的时候你会喜欢。"
    jump Character15771
label Character14771:
    scene kj16
    jst2"北京的雨和巴黎的不一样。"
    jst1"你之前在巴黎？"
    jst3"听见他问起你在国外的经历，那些冷调的记忆翻涌上来"
    jst1"看你像是曾经在国外待很久？"
    jst2"（淡淡笑了笑）从大学开始就一个人在国外待着了，家里人让我学设计，但我现在还是跑回国来做运营。（苦笑）"
    jst1"一个人在外，应该会很辛苦。"
    jst3"你没想到他会这样说"
    jst1"年少有为很不容易。"
    jst3"你突然很烦躁，突然意识到他是不是对所有人都这样共情"
    jst2 "我还以为你会觉得我很叛逆。"
    jump Character15771
label Character15771:
    scene kj14
    menu:
        "邀请他下次一起喝咖啡":
            $ Affinity += 3
            jump Character16771
        "说起巴黎时装周":
            $ Concession += 2
            jump Character17771

label Character16771:
    scene kj14
    jst3"一杯咖啡刚好喝完，窗外的雨适时地停了"
    jst2"下次我们还有机会一起喝咖啡吗？"
    jst1"（笑得眯了眼）只要你不怕失眠。"
    jst3"你笑起来，终于明白为什么他的拍摄现场总是那么欢乐"
    jump Character18771
label Character17771:
    scene kj14
    jst2"你去过巴黎吗？"
    jst1"你要说巴黎，那我可去过深圳的世界之窗。"
    jst3"你忍不住笑起来，突然很想带他去看你生活过的地方"
    jst2"你想去玩一圈吗？"
    jst2"别多想啊，我是觉得时装周很适合你，刚好我们下一季的产品想要过去参展，大概是明年一月份。"
    jst2"我是真心地邀请你去。"
    jst1"燕总给我这么好的机会那我当然要去了。"
    jst3"一杯咖啡刚好喝完，窗外的雨适时地停了"
    jst2"那就这么说定了，我回去拟好新的合同发给你。"
    jump Character18771

label Character18771:
    scene black with fade
    scene kj5
    jst3"拍摄结束后的两周里，你一直在寻找一个契机见面"
    jst3"对话框里的文字敲了又删，你始终不知道该如何开口"
    jst3"你听说他私下里总是淡淡的，很少答应别人的聚会邀请"
    jst3"但他对你的态度又总是让你产生一种错觉。"
    jst3"最后，你让助理做了一版简单的时装周参展策划给他发了过去"
    jst2"巴黎时装周，希望你会喜欢。"
    jump Character19771

label Character19771:
    scene black with fade
    scene kj15
    show text "北京迎来了第一场寒潮"
    $ renpy.pause()
    hide text with dissolve
    show text "那天你加班到深夜，走出写字楼的时候外面下了雨夹雪"
    $ renpy.pause()
    hide text with dissolve
    show text"你随手发了一条朋友圈抱怨这个鬼天气还要加班后切到了打车软件"
    $ renpy.pause()
    hide text with dissolve
    show text "已经是午夜十二点，你不想麻烦司机来接一趟于是干脆打车回家"
    $ renpy.pause()
    hide text with dissolve
    play sound md_1
    show text "就在你等着出租车接单的时候，一辆黑色迈巴赫在路边停下来"
    $ renpy.pause()
    hide text with dissolve
    show text "你还在疑惑这应该不是自己叫的车"
    $ renpy.pause()
    hide text with dissolve
    show text "车窗稳稳降下，露出精致的一张脸"
    $ renpy.pause()
    scene black with fade
    scene kj17
    jst1 "上车。"
    jst1 "这里不让停太久。"
    jst3 "你愣了一下，拉开车门坐了进去"
    scene kj18
    jst3 "车里很暗，只有路灯的光一闪一闪地掠过他的侧脸"
    jst2 "你怎么会在这儿？"
    jst1 "刚好路过。"
    jst1 "（看着前方）"
    jst1 "看到有个傻子在淋雨。"
    jst3 "车里放着很轻的纯音乐"
    jst3 "暖气开得很足，空气里混合着一种极淡的乌木味道"
    jst3 "那是他身上特有的味道"
    jst1 "倒是你，大半夜不睡觉还在公司加班？"
    jst2 "嗯，年底了。"
    jst3 "他沉默了一会儿"
    jst1 "以你的职位，应该不用这样亲力亲为吧。"
    jst2 "你说得没错，但...我毕竟是新人嘛，不想让别人觉得我是靠家里才坐到这个位置。"
    jst2 "但我最近觉得...事实好像真的是这样。（苦笑）"
    jst1 "怎么？燕总轻易就会因为别人的几句话内耗？"
    jst2 "才没有。（撇过脸）"
    jst1 "（见你不愿多说，轻叹一口气）其实你没必要非去陷入一个自证怪圈，你的能力和家世都是你的底气。"
    jst3 "他说这话的时候很认真地看着你，带着关切的语气"
    jst2 "【我的能力和家世...都是我的底气吗？】"
    jst3 "你靠着车窗，视线落到他沾着雪花的皮鞋上，亮晶晶的"
    menu:
        "告诉他你的住址":
            $ Concession += 3
            jump Character20771
        "一路无言":
            $ Affinity += 2
            jump Character21771
    jst3 "车子开得很稳，你吹着暖风终于忍不住沉沉睡去"
label Character21771:
    scene black with fade
    scene kj20
    jst1"醒醒，到了。"
    jst3"乌木的香气欺压过来，你睁眼看见魏大勋已经打开了你这边的车门"
    jst2"（灯光晃得你睁不开眼）到哪了？"
    jst1"我的酒店。"
    jst1"我可不是趁人之危啊，你又没告诉我你家在哪。正好我剧组酒店离着近，你就在这凑合一晚吧，助理已经订好房间了，工作人员也都跟着呢。"
    scene black with fade
    scene kj21
    jst3"他在前面撑伞稳稳地走着"
    jst3"宽阔的背影让你有种莫名的心安"
    jst3"你反复告诉自己这不是梦"
    jump Character24771

label Character24771:
    scene black with fade
    scene kj22
    jst3"洗漱之后已经凌晨两点了，刚刚车上那一觉睡得很安稳，现在反倒睡不着了"
    jst3"你打开微博随意刷着"
    jst3"从前你总是通过这个软件获取他的一切近况，自从你们有了联系之后你就很少打开了"
    jst3"他今天看样子是刚下戏，你有点好奇是什么剧组要拍到这么晚"
    jst3"你突然发现不对，瞬时脑子里闪过一万种玛丽苏小说情节"
    jst3"当年果郡王去宁古塔也说顺路。。"
    jst3"你想起刚刚那条朋友圈，不敢再去想一些细节"
    jst2"也许人家真是顺路呢。"
    jst2"找时间请他吃饭好了。"
    jump Character25771

label Character20771:
    scene black with fade
    scene kj20
    jst1"醒醒，到了。"
    jst3"乌木的香气欺压过来，你睁眼看见魏大勋已经打开了你这边的车门"
    jst2"（灯光晃得你睁不开眼）到哪了？"
    jst1"（笑着）自己家不认识了？（递伞）"
    jst2"（不好意思）今天真的很谢谢你...我请你吃饭吧，还有巴黎行程的细节我也一并敲定了发给你。"
    jst1"行了妹妹，还聊工作呢，你这不早了赶紧回去休息吧。"
    jst3"你再次道了谢，接过伞向小区门口走去"
    jst3"车灯在你身后亮了很久"
    jump Character22

label Character22771:
    scene black with fade
    scene kj22
    jst3"洗漱之后已经凌晨两点了，刚刚车上那一觉睡得很安稳，现在反倒睡不着了"
    jst3"你打开微博随意刷着"
    jst3"从前你总是通过这个软件获取他的一切近况，自从你们有了联系之后你就很少打开了"
    jst3"他今天看样子是刚下戏，你有点好奇是什么剧组要拍到这么晚"
    jst3"你突然发现不对，瞬时脑子里闪过一万种玛丽苏小说情节"
    jst3"当年果郡王去宁古塔也说顺路。。"
    jst3"你想起刚刚那条朋友圈，不敢再去想一些细节"
    jst2"也许人家真是顺路呢。"
    jst2"找时间请他吃饭好了。"
    jump Character23771

label Character25771:
    scene black with fade
    scene kj23
    jst3"一周后，你得知魏大勋的新戏杀青了"
    jst3"你挑了一家隐蔽性极好的私人餐厅，想着一来算是还他那晚的人情，二来正好庆祝他杀青"
    scene kj24
    jst3"他到的时候包厢里刚好放着一首很老的爵士乐"
    jst3"他换了件黑色的高领毛衣，头发散散地搭在额前"
    jst3"网上很火的那句话怎么说的来着？"
    jst3"哦对，人夫感"
    jst1 "来得这么早？"
    jst2 "（笑着）怕大明星档期太满来不及赶通告。"
    jst3"你知道他明天一早就要飞到另一个城市"
    jst1 "（他低低地笑了一声）"
    jst1 "燕总这么盛情邀请那我必须有档期吧。"
    jst3"他拉开椅子的声音很轻"
    play sound sz_1
    jst3"席间你倒是没有急着开口提巴黎的策划案"
    jst3"房间里只有偶尔瓷勺碰到骨碟的轻响"
    jst3"你正低头喝汤，他突然用公筷夹了一块挑了刺的鱼肉放进你面前的碟子里"
    jst1 "那天晚上..."
    jst1 "（顿了顿）"
    jst1 "没经过你同意就把你送到酒店实在是不好意思。"
    jst3"他突如其来的道歉让你心里一紧"
    menu:
        "顺着他的话往下问":
            $ Affinity += 3
            jump Choice_Tease1
        "低头吃鱼掩饰慌乱":
            $ Concession += 2
            jump Choice_Escape1

label Choice_Tease1:
    scene kj25
    jst2 "嗯？（笑着）那怎么没叫醒我？"
    jst3"他放下筷子，手攥得紧了些"
    jst3"包厢里暖黄色的灯光衬得他的脸有些不明，像一场梦境"
    jst1 "看你在车里睡着了..."
    jst1 "（自嘲地笑了一下，避开了视线）"
    jst1 "（苦笑）如果叫醒你有点残忍。"
    jst3"冠冕堂皇"
    jump Character26771

label Choice_Escape1:
    jst2"（低头）这鱼挺好吃的。"
    jst2"嗯...是我该谢谢你。"
    jst1 "（轻叹了一口气）"
    jst3 "你看到他垂下的眼睫似乎微微颤动了一下"
    jump Character26771

label Character23771:
    scene kj23
    jst3"一周后，你得知魏大勋的新戏杀青了"
    jst3"你挑了一家隐蔽性极好的私人餐厅，想着一来算是还他那晚的人情，二来正好庆祝他杀青"
    scene kj24
    jst3"他到的时候包厢里刚好放着一首很老的爵士乐"
    jst3"他换了件黑色的高领毛衣，头发散散地搭在额前"
    jst3"网上很火的那句话怎么说的来着？"
    jst3"哦对，人夫感"
    jst1 "来得这么早？"
    jst2 "（笑着）怕大明星档期太满来不及赶通告。"
    jst3"你知道他明天一早就要飞到另一个城市"
    jst1 "（低低地笑了一声）"
    jst1 "燕总这么盛情邀请那我必须有档期吧。"
    jst3"他拉开椅子的声音很轻"
    jst3"席间，你没有急着开口提巴黎的策划案"
    jst3"房间里只有偶尔瓷勺碰到骨碟的轻响"
    jst2 "明天一早的飞机..."
    jst2 "怎么会这么赶？身体吃得消？"
    scene kj25
    jst1"（放下筷子，挑挑眉）嗯？"
    jst2"（抬头）"
    jst1"（笑得眯了眼）燕总这么关心乙方。"
    menu:
        "我还以为我们算朋友来着":
            $ Affinity += 3
        "我亲自找的乙方自然要多上心":
            $ Concession += 2
    jst3"你感觉到他似乎愣了一秒"
    jst1"那我以后可要多和燕总套套近乎了。"
    jump Character26771

label Character26771:
    scene kj27
    jst3"吃完饭出来你发现时间还早"
    jst2"这家餐厅是我朋友开的，后面有一个私人公园，要不要逛逛？"
    jst1"也好。"
    scene kj26
    jst3"已经是初冬，魏大勋穿着一身羽绒服"
    jst3"他本来走得很快，发现你有点跟不上他就放缓了脚步"
    jst2"巴黎有很多公园，我晚上也会过去散步。"
    jst1"你很喜欢那里么？"
    jst2"也不算吧，只不过在我的人生阅历里，有挺多重要的时刻都是在那里度过的。"
    jst2"但是那里的饭很难吃（笑）"
    jst1"我也不爱吃外国菜，可能我是中国胃。"
    jst2"不过十三区有一家中餐很好吃，我们到时候可以去尝尝。"
    jst3"中餐邀请脱口而出的时候你们正在下台阶"
    scene kj28
    jst1"（回头看了你一眼）好。"
    jst3"你习惯了他总是打趣似的回答，没想到他只说了一个好字"
    jst3"你在思考这样太过热情的邀请是否有点越界，但管他呢，反正魏大勋同意了"
    jump Character27771


label Character27771:
    scene black with fade
    scene kj29
    "几周后"
    "因为这次参展团队的人数不少，你干脆包了一架中型的商务客机直飞巴黎"
    "飞了几个小时大家都有些困，于是你吩咐调暗了机舱里的灯"
    "你和魏大勋坐在后排靠窗最舒适的位置"
    "困意如潮水般涌上来"
    "你原本想撑着再完善一些参展细节，但眼皮最终不受控制地合上了"
    "不知道过了多久"
    "飞机遇到了一阵轻微的气流颠簸"
    "你迷迷糊糊地醒来却发现自己并没靠在机舱壁上"
    "当你意识过来不对劲的时候已经晚了"
    "你的头正靠在一个温热的肩膀上"
    "熟悉的乌木味道将你完完全全地包裹着"
    "你猛地清醒过来，想要坐直身体"
    
    jst1 "（低声）"
    jst1 "你醒了？"
    
    "机舱里很安静"
    "他压低了声音，只有你们两个人能听见"
    jst2 "抱歉，实在对不起，我睡着了不知道怎么就...（环顾四周）"
    "你边道歉边拉开距离"
    "但他的肩膀依旧保持着刚才姿势没变"
    jst1 "（打断）没事。"
    jst1 "（偏过头，在昏暗的光线里看着你）"
    jst1 "为甲方服务。"
    "你才发现他的手只是抱着臂，还是一副绅士样子"
    "而你的腿上不知道什么时候盖上了他的毯子，座椅也好像被向后调了调" 
    menu:
        "把毯子还给他，有些不好意思":
            $ Affinity += 2
            jump Choice_Return_Coat22
        "低声问他为什么不叫醒你":
            $ Concession += 3
            jump Choice_Ask_Why22

label Choice_Return_Coat22:
    jst2 "我不冷了，毯子还你吧。"
    jst3"说着你就要拿起腿上的毯子"    
    jst1 "得了，披着吧。"
    jst3"依旧是淡淡的语气"
    jump Character32771
label Choice_Ask_Why22:
    jst2 "你干嘛不叫醒我。"
    
    "他沉默了一会儿"
    "借着机舱里微弱的指示灯光，你看到他的喉结滚动了一下"
    
    jst1 "问题不大。"
    jump Character32771
label Character32771:
    scene kj30
    jst3"飞机上的人也陆陆续续醒过来"
    jst3"他拉开飞机窗户的挡板，外面竟是一片晚霞"
    jst3"你们默契地拿出了手机想要记录，他已经换了手机壳，但印花依旧是一只布朗熊"
    jst3"他记录的是晚霞，而你记录的其实是他"
    jst3"为了掩饰，你还是拍了几张风景照，随后把偷拍的照片存入了私密相册"
    jst1"怎么样？（拿过手机给你展示）"
    jst2"大明星还搞起摄影师副业了？"
    jst2"你如果不拍戏可以去当摄影师。"
    jst1"（打趣着）我这是给角色积累经验，万一我以后演了个摄影师。"
    jst1"不过啊，我最想当的还是老师，我喜欢管着别人（笑）。"
    jst3"你没忍住笑出声，打开手机准备给他看你刚刚拍的晚霞"
    jst3"相册分类的界面里，微信分类的的封面赫然放着你偷偷存下的他拍的雨滴"
    jst2"【完蛋了，他应该没看到吧】"
    jst2"（快速划过）"
    jst1"（脸上没什么特殊的表情，似乎是什么也没看到）"
    jump Character31

label Character31:
    scene black with fade
    scene kj31
    jst3"飞机准时降落在机场"
    jst3"巴黎又在下雨"
    jst1"我一会绕到普口出方便吗？"
    jst2"不走V？"
    jst1"我估计她们都在普口等着（笑），大老远过来不容易。"
    jst2"那好，我们先上车再过去接你也可以，这倒是不麻烦。"
    jump Character33

label Character33:
    scene kj32
    "拍摄日这天，他的无名指戴上了你设计的那枚戒指"
    "骨节分明的手指点缀上碎钻称得上世间最完美的艺术品"
    jst2"很适合你。"
    jst1"跟定制似的，燕总艺术天分极高啊。（举着手在你眼前晃了晃）"
    jst2"少贫。"
    jst3"魏大勋拍摄表现力一向很好，拍摄结束时巴黎天还亮着"
    jst3"你让工作人员回去休息，只带了两个助理和他一起走在巴黎的街上"
    scene kj33
    jst3"他的私服是黑色大衣，拿一把黑伞，整个人又回到私下里冷冷的气质"
    jst2"（开玩笑）如果我走在路上遇到你一定不敢搭讪。"
    jst1"怎么说？"
    jst2"没有人会敢搭讪一个冰川型男子。"
    jst1"你这是夸我呢还是损我呢？"
    menu:
        "你猜":
            $ Concession += 3
            jump Choice_A
        "我可不敢挑大明星的毛病":
            jump Choice_B
            $ Affinity += 2
        
label Choice_A:
    jst1"得了吧，甲方的心思我可不敢猜。"
    jst2"那我要不是作为你的甲方呢？"
    jst1"（眨眨眼）嗯？"
    jst2"嗐，我随便说的。"
    jump Character34
    
label Choice_B:
    jst1"妹妹那你这么说可见外了（笑）"
    jst3"你也忍不住笑起来"
    jump Character34

label Character34:
    stop music fadeout 2.0
    play sound sdg_2
    scene kj34
    "走秀这天是巴黎难得的好天气"
    "你作为设计师其中之一和魏大勋一起迈进了秀场的大门"
    jst2"还没正式开始，现在这些都是拍照和social环节。"
    jst1"嗯。"
    play music"mlh.mp3" 
    jst3"闪光灯似乎一刻也没停歇，你很讨厌这种时时刻刻被记录的感觉"
    jst3"你本来还担心魏大勋会紧张，没想到他比你要游刃有余"
    stop sound
    jst3"你看着他脸上亮了又暗"
    jst3"好像他生来就该这样，灯红酒绿、华服加身、游戏人间"
    jump Character35

label Character35:
    scene black with fade
    scene kj35
    "行程的最后一晚是庆功宴"
    "过了今晚就意味着巴黎之行结束了"
    "当初你们的合约并没签太久，所以这就意味着在未来一段时间内你们都不会再有交集"
    "车上"
    jst2"（深吸一口气）我带你去十三区吃中餐吧。"
    jst2"（不等他回答）别拒绝我，别告诉我你想去无聊的庆功宴。"
    jst1"走吧。"
    jst3"他眼里又映着幽蓝色的光，就像你第一次见到他那样"
    scene kj36
    jst2"我想家的时候就会来这吃一顿。"
    jst3"你喝了点酒，眯着眼看他"
    jst1"确实，很正宗（点头）"
    jst1"吃完这一顿明天脸也得肿（笑着）。"
    jst2"你这大明星，都不知道该说你什么好，太自律。"
    jst2"你要不是明星就好了（托着脸看他）。"
    jst2"但那样的话我们应该就不会遇见了（低下头）。"
    jst1"也许挺可惜的。"
    menu:
        "你就算没有遇到我也会来到这里的":
            $ Concession += 2
            jump Choice_C

        "为什么":
            $ Affinity += 3
            jump Choice_D
    label Choice_C:
        scene kj41
        jst2"你就算没有遇到我也会来到这里的"
        jst2"在我们遇见之前...我看你的戏很久了。"
        jst2"但你私下和屏幕里相差很大（笑）"
        jst1"是么？"
        jst2"嗯，从前我觉得你的搞笑天分占百分之八十，但现在我觉得不是。"
        jst1"那是什么？"
        "他到底是什么样"
        "好像你也看不真切"
        "你有时候觉得他琥珀色的瞳孔里藏着某种随性和淡然"
        jst3"你一时语塞，脑子里又闪过那八个字"
        jst3"华服加身，游戏人间"
        jst2"（笑）不可泄漏。"
        jst1"（喝一口酒）得了吧，还搞上道士那一套了。"
        jst2"我说真的，我觉得你能成大事。"
        jst1"那我就...借你吉言。"
        jst3"你们边吃边聊了很久"
        jump Character37
    label Choice_D:
        scene kj41
        jst1"（握着酒杯）什么为什么？"
        jst2"为什么觉得可惜？"
        jst3"这话你本不该问出口的，但你固执地想要一个答案"
        jst1"（只是笑笑）你喝多了妹妹。"
        jst2"没有。我很清醒。"
        jst1"（看着拗不过你）没什么，就是觉得...多一个朋友多一个资源吧。"
        jst2"你知道自己撒谎的时候很明显吗？"
        jst1"有吗？"
        jst3"酒杯挡住他的脸，你看不真切"
        jst3"你不想闹得太尴尬，终归还是没再问下去"
        jump Character37
label Character37:
    scene black with fade
    scene kj36
    jst2"回国之后什么打算？"
    jst1"有新戏在接触了，顺利的话夏天开机。"
    jst1"一个挺不一样的角色。"
    jst2"和你本人相差很大吗？"
    jst1"（只是笑笑）"
    jst2"行吧，那就祝大明星，星途璀璨。"
    jst3"此时的你们还未知晓，一个燥热的夏天很快就要到来"

    label Character36:
        scene black with fade
        scene kj35
        "走出中餐厅的时候，冷风一吹酒意上头得更厉害了"
        jst2"（脚步有些虚浮）"
    
        if Affinity>Concession:
            jump HE
        if Affinity<Concession:
            jump BE
        if Affinity == Concession:
            jump OE

    label HE:
        scene black with fade
        scene kj37
        jst3 "他走在你身旁不动声色地护着"
        jst1 "以后不能让你喝这么多酒了。"
        jst2 "我可没醉……"
        jst3 "你嘟囔着，下意识往他身边靠了靠"
        scene kj38
        jst1"想靠就靠着呗妹妹（轻笑）。"
        jst2"嗯？"
        jst3"你猛地抬头，看见他嘴边挂着浅浅的梨涡"
        jst2"你耍我!害得我刚才弄那么伤感，我还以为我们真的要相忘于江湖了喂！"
        jst3"他的臂弯环过来，下巴轻轻擦过你的发顶，你听见他胸腔里的震动"
        jst1"（笑）你就那么舍不得我啊。"
        jst2"哎呀你这个人真的是。"
        jst3"你刚挣脱出来想锤他，一个吻铺天盖地地落下"
        jst3"你想起设计那枚戒指的夜晚"
        jst3"屏幕里的电视剧演到结尾，他终于落下一滴泪"
        jst3"你无意识地在戒指草稿旁边写下一句话"
        jst3"一定会在巴黎的雨夜，我在你身边"
        jst3"解锁成就：在你身边"
        return

    label BE:
        scene black with fade
        scene kj39
        jst1"回酒店吧，明天还要坐一天飞机。"
        jst2"嗯。看你这几天都没怎么吃，你的胃跟着你也受苦了。"
        jst1"（微笑着）燕总，我要感谢这次合作，让我收获了很不一样的体验。"
        jst1"但就像你说的，可能我还是个中国胃吧。"
        jst2"（抬头笑着）好吧。"
        jst2"有缘我们再合作。"
        jst3"巴黎又下起雨，你明白也许你们有不同的路要走"
        jst3"就像电影里说的："
        jst3"如果开始是结束的开始，我宁愿不要按下启动键"
        jst3"既然是明月，那就还请高悬于夜空吧，不必因为某些停留而错过什么"
        jst3"但你坚信，宇宙会让相逢的人再相逢"
        jst3"解锁成就：明月高悬"
        return

    label OE:
        scene black with fade
        scene kj35
        "你不知道你是怎样回到酒店的，只是不顾一切地、 坠落着睡去"
        scene kj40
        "早上九点，外面依旧阴沉沉的，你从一场无边的梦中醒来"
        "手机屏幕亮起，界面还停在他在巴黎站在聚光灯下的照片"
        "“魏大勋又维护老客户了”你随手在社交平台发布了一条帖子"
        "你看向窗外"
        "发现北京又在下雨"
        "解锁成就：梦里花"
        return